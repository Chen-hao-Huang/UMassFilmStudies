Thanks to the PhpCaptcha authos; PhpCaptcha contains the image generation code, 
EasyCaptcha acts as a wrapper around it, using standard PhpCaptcha options to 
make a good captcha and providing file/database-free captcha-code validation.

See http://kestas.kuliukas.com/EasyCaptcha/ for info on how to use it in your code
See http://kestas.kuliukas.com/EasyCaptchaPHPBB/ for info on how to use it in PHPBB2/3

Requirements
------------
PHP4.2+ (May work with older versions)
GD with FreeType enabled